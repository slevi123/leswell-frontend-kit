# leswell-frontend-kit
frontend solutions for myself.

### Installation
download it from Pypi
**link coming**

## javascript module loader

_import rule in js files_:\
` imports = [ "builtin-module", "submodule",... ] `\
**note:** _space is neccesary after `imports`_ keyword

cli tool:\
`lesjs inputfile outputfolder`\
or\
`lesjs inputfile -o outputfile`